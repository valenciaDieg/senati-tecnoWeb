
package Casos;

public class Datos {
    //propiedades
    public String Codigo;
    public String Apellidos;
    public String Asignatura;
    public double Nota1;
    public double Nota2;
    public double Nota3;
    public double pro; //promedio
    public String SA; //situacion academica
    //metodos
    public double CalcularPromedio(){
        pro=(Nota1+Nota2+Nota3)/3;
        return pro;
    }
    public String HallarSituacionAcademica(){
        if(pro>=10.5){
            SA="Aprobado";
        } else {
            SA="Reprobado";
        }
        return SA;
    }
    //metodo constructor
    public Datos(){
    };
}
